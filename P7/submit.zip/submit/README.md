# SparshAgarwal
# GraphicsTownJS2017
The files used in the project are:
ground.js
cube.js
kindOfBall.js
bikesandseats.js
house.js
road.js
helicopter.js(modified)
graphicstown.js
grobject.js
index.html
readme.md

Definition for town:
There is an overhead water tank in north west which will have the name of town
All the things have specular lighting as well
All the houses have a vehicle in red on their right
There is a pond between the houses and the pond has grey seats around it. 
There is a airship that air patrols the city.
The airship lands only on the helipad, not on any house.
It chooses its path randomly.